<hr>

<div class="footer">
    Powered by, <a href="http://www.directorylister.com">Directory Lister</a>
</div>
